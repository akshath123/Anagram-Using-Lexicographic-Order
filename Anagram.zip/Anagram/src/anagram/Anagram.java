package anagram;

import java.awt.* ;
import java.sql.* ;
import javax.swing.* ;
import java.awt.event.* ;

public class Anagram extends JFrame implements ActionListener{

    JTextField input ;
    JButton bi[] = new JButton[30] ;
    JButton undo, reset, anagram_it ;
    String word = "" ;
        
    Anagram()
    {
        super("Anagram") ;
        setSize(680, 680) ;
        int char_flag = 0 ;
        
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/background1.jpg"))) ;
        add(background) ;
        
        background.setLayout(new FlowLayout()) ;
        
        background.add(Box.createVerticalStrut(100)) ;
        
        JPanel p1 = new JPanel() ;
        p1.setOpaque(false);
        
        JLabel title= new JLabel(" Anagram Using Lexographic ") ;
        title.setForeground(Color.white) ;
        title.setFont(new Font("Lucida Calligraphy",Font.BOLD,30)) ;
        
        p1.setLayout(new FlowLayout(FlowLayout.CENTER,70,20)) ;
        p1.add(title) ;
      
        JPanel p2 = new JPanel() ;
        p2.setOpaque(false) ;
        p2.setLayout(new FlowLayout(FlowLayout.CENTER,150,60)) ;
        input = new JTextField(20) ;
        input.setForeground(Color.black) ;
        input.setHorizontalAlignment(JTextField.CENTER);
        input.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                dispose() ;
                anagram_It() ;
            }
        }) ;
        input.setFont(new Font("Serif",Font.BOLD,20)) ;
        p2.add(input) ;
           
        JPanel p3 = new JPanel() ;
        p3.setOpaque(false) ;
        p3.setLayout(new GridLayout(5,5,6,5)) ;
        for( int i = 0 ; i < 30  ; i++ )
        {
            
            if( i == 6 || i == 11 || i == 18 || i == 23 )
            {
                bi[i] = new JButton("") ;
                bi[i].setContentAreaFilled(false) ;
                bi[i].setBorder(null);
                p3.add(bi[i]) ;
            }
            else 
            {
                char ch = (char)(char_flag+97) ;
                bi[i] = new JButton("" +ch) ;
                bi[i].setFont(new Font("Rockwell Condensed",Font.BOLD|Font.ITALIC,20)) ;
                bi[i].addActionListener(this) ;
                bi[i].setPreferredSize(new Dimension(100,35)) ;
                bi[i].setForeground(Color.black) ;
                bi[i].setFocusPainted(false) ;
                char_flag++ ;
                p3.add(bi[i]) ;
            }
          } 
        
        JPanel p4 = new JPanel() ;
        p4.setOpaque(false) ;
        p4.setLayout(new FlowLayout()) ;
        
        undo =  new JButton("Undo") ;
        undo.setFont(new Font("Rockwell Condensed",Font.BOLD|Font.ITALIC,20)) ;
        undo.setPreferredSize(new Dimension(100,35));
        undo.setFocusPainted(false) ;
        undo.setForeground(Color.black);
        undo.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                String str = input.getText() ;
                int len = str.length() ;
                word = str.substring(0,(len-1)) ;
                input.setText(word) ;
            }
        }) ;
        
        reset = new JButton("Reset") ;
        reset.setFont(new Font("Rockwell Condensed",Font.BOLD|Font.ITALIC,20)) ;
        reset.setPreferredSize(new Dimension(100,35)) ;
        reset.setFocusPainted(false) ;
        reset.setForeground(Color.black) ;
        reset.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                word = "" ;
                input.setText("") ;
            }
        });
        
        p4.add(undo) ;
        p4.add(reset) ;
        
        JPanel p5 = new JPanel() ;
        p5.setOpaque(false);
        p5.setLayout(new FlowLayout(FlowLayout.CENTER,150,50));
        anagram_it = new JButton("Anagram it") ;
        anagram_it.setPreferredSize(new Dimension(150,35));
        anagram_it.setFocusPainted(false) ;
        anagram_it.setFont(new Font("Rockwell Condensed",Font.BOLD|Font.ITALIC,20)) ;
        anagram_it.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                anagram_It() ;
            }
        }) ;
        p5.add(anagram_it) ;
     
        background.add(p1) ;  
        background.add(Box.createVerticalStrut(80)) ;
        background.add(p2) ;
        background.add(Box.createVerticalStrut(100)) ;
        background.add(p3) ;
        background.add(p4) ;
        background.add(p5) ;
    }
    
    public static void main(String[] args) {
        Anagram an = new Anagram() ;
        an.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        an.setLocationRelativeTo(null) ;
        an.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        word = input.getText() ;
        String letter = (String) ae.getActionCommand() ;
        word += letter ;
        input.setText("" +word) ;
    }
    
    public void anagram_It()
    {
        dispose() ;
        word = input.getText() ;
        Ana an = new Ana(word);
    }
}

class Ana extends JFrame implements ActionListener{
    
    JButton back ;
    static String word ;
    int a[] = new int[100] ;
    TextArea disp ;
    static int sno = 1 ;
    
    Ana(String word)
    {
        this.word = word ;
        System.out.println(word) ;
        change_path(word) ;
    }
    
    public void change_path(String word)
    {
        Ana ob = new Ana(1,word) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
    }
    
    Ana(int i,String word)
    {
        super(" List of Anagrams ") ;
        
        setSize(680,680) ;
        setVisible(true) ;
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/background1.jpg"))) ;
        add(background) ;
        
        background.setLayout(new FlowLayout(FlowLayout.CENTER,150,20)) ;
        
        disp = new TextArea(30,60) ;
        disp.setEditable(false) ;
        
        back = new JButton(" BACK ") ;
        back.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,20)) ;
        back.setPreferredSize(new Dimension(100,30)) ;
        back.addActionListener(this) ;
        
        background.add(disp) ;
        background.add(back) ;
        
        searching(word) ;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        dispose() ;
        Anagram ob = new Anagram() ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ob.setLocationRelativeTo(null) ;
        ob.setVisible(true) ;
    }
    
    public void searching(String word)
    {
                int fact = 1 ;
		
		int indexn, length_of_numbers ;

                int num = word.length() ;
		length_of_numbers = indexn = num - 1 ;
	//	System.out.println(indexn) ;

		System.out.println(" The array values are") ;
		for( int i = 0 ; i < num ; i++ )
		{	
			a[i] = i+1 ;
			System.out.println(" a[" +i +"] = " +a[i]) ;
		}

		for( int i = 1 ; i <= num ; i++ )
		{	fact = fact * i ; }

	//	System.out.println(" The factorial value is " +fact) ;
        
                while( (fact-1) != 0 )
		{
			if( a[indexn] > a[indexn-1] )
			{
				word = swap(word, indexn,indexn-1 ) ;
				indexn = length_of_numbers ;
			}
			else if( a[indexn] < a[indexn-1] )            
			{
				if( a[indexn] > a[indexn-2] && a[indexn-1] > a[indexn-2] )
				{
					word = swap( word,indexn-2,indexn ) ;
					word = sort(word,indexn-1,length_of_numbers) ;
					indexn = length_of_numbers ;
				}
				else if( a[indexn] < a[indexn-2] )
				{
					int x = indexn ;
					int y = x ;
					x = x - 1;
					while( a[x] > a[y] )
					{
						y = x ;
						x-- ;
						if ( x < 0 )
							{ break ; }
					}
					if( a[x] < a[indexn] )
					{
						word = swap(word, x,indexn ) ;
						word = sort(word, x+1,length_of_numbers ) ;
						indexn = length_of_numbers ;
					}
					else
					{
						indexn = x+1 ;
						word = swap(word, indexn,indexn-1 ) ;
						word = sort(word,indexn,length_of_numbers) ;
						indexn = length_of_numbers ;		
					}
				}
			}
        
                        System.out.print(sno++ +"-->") ;
			for( int i = 0 ; i <= length_of_numbers ; i++ )
			{
				System.out.print(" " + a[i]) ;
			}
                        System.out.println() ;
                        
                      try{
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/maths","root","forgotpass1");
                            
                            Statement stm = con.createStatement() ;
                            
                            String sql = " SELECT * FROM words " ;
                            
                           ResultSet rs = stm.executeQuery(sql) ;
                            
                          while(rs.next())
                            {
                                String text = rs.getString("word") ;
                                if( text.equals(word))
                                { 
                               System.out.println() ;
                          	System.out.println(word) ;
                                disp.append("\n\n" +"                                                                 "+word );
		
                      }
                            }
                        }catch(SQLException e)
                        {
                            System.out.println("exception");
                            System.out.println(e) ;
                        }
			fact-- ;
		}
                
    }
    
         String swap(String word, int index1, int index2 )
	{
            	int temp ;
		StringBuilder temp_word = new StringBuilder(word) ;
		char ch1 = word.charAt(index1) ;
		char ch2 = word.charAt(index2) ;
		temp_word.setCharAt(index2,ch1) ;
		temp_word.setCharAt(index1,ch2) ;
		word = temp_word.toString() ;
            	temp = a[index1] ;
		a[index1] = a[index2] ;
		a[index2] = temp ;
                return word ;
	}

	String sort(String word, int index1, int n )
	{
		int temp ;
		for( int i = index1 ; i <= n ; i++ )	
		{
			for( int j = i+1 ; j <= n  ; j++ )
			{
				if( a[i] > a[j] )
				{
                                    StringBuilder temp_word = new StringBuilder(word) ;
                                    char ch1 = word.charAt(i) ;
					char ch2 = word.charAt(j) ;
					temp_word.setCharAt(i,ch2) ;
					temp_word.setCharAt(j,ch1) ;
                        		word = temp_word.toString() ; 
                                        temp = a[i] ;
					a[i] = a[j] ; 
					a[j] = temp ;
				}
			}
		}
                return word ;
	}
}   